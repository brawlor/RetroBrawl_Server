# JavaBrawl
First open-source Java 11 Brawl Stars server for version 19!

##### Need help? Join my [Discord Server](https://discord.gg/YuV4PbwX99) or Vitalik's [Discord Server](https://discord.gg/UjfNxMt82F)

## How to start
#### Requirements:
- [JDK 11](https://www.oracle.com/java/technologies/javase-jdk11-downloads.html)
- [Patched APK](https://drive.google.com/file/d/1N6VtHPGB7PN1v-t9HLULKMjJdm63kIpz/view?usp=sharing)

Next step you need compile the server to jar or use prebuilt jar from releases

To run the server use this command:

```
java -jar JBrawl.jar
```

## Need help?
Contact me on Discord (Xeon-DEV#9984) or open an issue.
