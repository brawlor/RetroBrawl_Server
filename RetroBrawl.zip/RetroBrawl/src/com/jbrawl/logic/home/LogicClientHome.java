package com.jbrawl.logic.home;

import com.jbrawl.logic.Player;
import com.object.jnetwork.buffers.JByteBuffer;

import java.io.IOException;

public class LogicClientHome {
    public Player player;
    public LogicClientHome(Player player){
        this.player = player;
    }

    public void encode(JByteBuffer packet) throws IOException {
        packet.writeVInt(1); //timestamp
        packet.writeVInt(1); //timestamp

        packet.writeVInt(player.score); //trophies
        packet.writeVInt(player.score);

        packet.writeVInt(0);
        packet.writeVInt(95);
        packet.writeVInt(player.exp);

        packet.writeVInt(28);
        packet.writeVInt(player.iconID); //icon csv id

        packet.writeVInt(43);
        packet.writeVInt(player.nameColor); //name color id

        packet.writeVInt(0);
        packet.writeVInt(0);
        packet.writeVInt(0);

        packet.writeVInt(0);
        packet.writeVInt(0);
        packet.writeVInt(0);

        packet.writeVInt(0);
        packet.writeVInt(0);
        packet.writeVInt(0);
        packet.writeVInt(0);

        packet.writeVInt(0);
        packet.writeVInt(0);
        packet.writeVInt(0);

        packet.writeVInt(0);
        packet.writeVInt(0);
        packet.writeVInt(0);
        packet.writeVInt(0);

        packet.writeVInt(0);
        packet.writeVInt(0);

        packet.writeVInt(200);
        packet.writeVInt(0);
        packet.writeVInt(0);

        packet.writeVInt(500); //tickets
        packet.writeVInt(10);

        packet.writeVInt(16);
        packet.writeVInt(player.selectedBrawler); //selected brawler csv id

        packet.writeString("CA"); //region
        packet.writeString("v19"); //content support

        packet.writeVInt(0); //array

        packet.writeVInt(2019049);
        packet.writeVInt(100);
        packet.writeVInt(10);
        packet.writeVInt(30);
        packet.writeVInt(3);
        packet.writeVInt(80);
        packet.writeVInt(10);
        packet.writeVInt(50);
        packet.writeVInt(1000);
        packet.writeVInt(500);
        packet.writeVInt(50);
        packet.writeVInt(999900);

        packet.writeVInt(0);

        packet.writeVInt(8);
        {
            packet.writeVInt(0);
            packet.writeVInt(1);
            packet.writeVInt(2);
            packet.writeVInt(3);
            packet.writeVInt(4);
            packet.writeVInt(5);
            packet.writeVInt(6);
            packet.writeVInt(7);
        }
        packet.writeVInt(5); //maps
        {
            packet.writeVInt(1);
            packet.writeVInt(1);
            packet.writeVInt(0);
            packet.writeVInt(75992);
            packet.writeVInt(0);
            packet.writeVInt(15); //map csv
            packet.writeVInt(7); //map id
            packet.writeVInt(3); //state
            packet.writeString(null);
            packet.writeVInt(0);
            packet.writeVInt(0);
            packet.writeVInt(0);

            packet.writeVInt(1);
            packet.writeVInt(2);
            packet.writeVInt(0);
            packet.writeVInt(75992);
            packet.writeVInt(0);
            packet.writeVInt(15); //map csv
            packet.writeVInt(16); //map id
            packet.writeVInt(3); //state
            packet.writeString(null);
            packet.writeVInt(0);
            packet.writeVInt(0);
            packet.writeVInt(0);

            packet.writeVInt(1);
            packet.writeVInt(3);
            packet.writeVInt(0);
            packet.writeVInt(75992);
            packet.writeVInt(0);
            packet.writeVInt(15); //map csv
            packet.writeVInt(130); //map id
            packet.writeVInt(3); //state
            packet.writeString(null);
            packet.writeVInt(0);
            packet.writeVInt(0);
            packet.writeVInt(0);

            packet.writeVInt(1);
            packet.writeVInt(4);
            packet.writeVInt(0);
            packet.writeVInt(75992);
            packet.writeVInt(0);
            packet.writeVInt(15); //map csv
            packet.writeVInt(111); //map id
            packet.writeVInt(3); //state
            packet.writeString(null);
            packet.writeVInt(0);
            packet.writeVInt(0);
            packet.writeVInt(0);

            packet.writeVInt(1);
            packet.writeVInt(5);
            packet.writeVInt(0);
            packet.writeVInt(75992);
            packet.writeVInt(0);
            packet.writeVInt(15); //map csv
            packet.writeVInt(68); //map id
            packet.writeVInt(3); //state
            packet.writeString("TID_WEEKEND_EVENT");
            packet.writeVInt(0);
            packet.writeVInt(0);
            packet.writeVInt(0);
        }

        packet.writeVInt(0); //null event slot

        packet.writeVInt(8);
        {
            packet.writeVInt(20);
            packet.writeVInt(35);
            packet.writeVInt(75);
            packet.writeVInt(140);
            packet.writeVInt(290);
            packet.writeVInt(480);
            packet.writeVInt(800);
            packet.writeVInt(1250);
        }

        packet.writeVInt(8);
        {
            packet.writeVInt(1);
            packet.writeVInt(2);
            packet.writeVInt(3);
            packet.writeVInt(4);
            packet.writeVInt(5);
            packet.writeVInt(10);
            packet.writeVInt(15);
            packet.writeVInt(20);
        }

        packet.writeVInt(3);
        {
            packet.writeVInt(10);
            packet.writeVInt(30);
            packet.writeVInt(80);
        }

        packet.writeVInt(3);
        {
            packet.writeVInt(6);
            packet.writeVInt(20);
            packet.writeVInt(60);
        }

        packet.writeVInt(4);
        {
            packet.writeVInt(20);
            packet.writeVInt(50);
            packet.writeVInt(140);
            packet.writeVInt(280);
        }

        packet.writeVInt(4);
        {
            packet.writeVInt(150);
            packet.writeVInt(400);
            packet.writeVInt(1200);
            packet.writeVInt(2600);
        }
        packet.writeVInt(0); //??
        packet.writeVInt(200); //tokens available
        packet.writeVInt(20); //tokens plus

        packet.writeVInt(8640);
        packet.writeVInt(10);
        packet.writeVInt(5);
        packet.writeVInt(6);
        packet.writeVInt(50);
        packet.writeVInt(604800);

        packet.writeBool(false);

        packet.writeVInt(0); //array

        packet.writeVInt(1);
        packet.writeInt32(1);
        packet.writeInt32(41000007); //theme id

        packet.writeInt64(player.id); //id

        packet.writeVInt(0); //array

        packet.writeBool(false);

        packet.writeVInt(0);
        packet.writeVInt(0);

    }
}
