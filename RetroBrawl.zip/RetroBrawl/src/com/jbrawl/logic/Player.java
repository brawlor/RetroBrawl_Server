package com.jbrawl.logic;

import com.jbrawl.Session;

import java.io.*;
import java.util.HashMap;

public class Player {

    public static HashMap<Integer, Player> players = new HashMap<>();

    public int id;
    public String name = "";
    public int tutorialState = 2;
    public int exp = 8888; public int score = 4000; public int gems = 10000; public int gold = 10000;
    public int selectedBrawler = 0; public int roomID = 0; public int iconID = 0; public int nameColor = 0;
    public Session current; public int ticks = 0;
    public int[] unlockedBrawlers = new int[]{0, 4};

    private Player(int id) {
        this.id = id;
    }

    public void tick() {
        this.ticks++;
    }

    public static Player load(int id) {
        if (id == 0) {
            id = 1;
            System.out.println("Creating new account...");
            for (; players.containsKey(Integer.valueOf(id)); id++);
        }

        if (!players.containsKey(Integer.valueOf(id))) {
            players.put(Integer.valueOf(id), new Player(id));
        }

        return players.get(Integer.valueOf(id));
    }

    public static void loadSavedData() throws IOException {
        if (!(new File("players.dat")).exists()) {
            return;
        }

        DataInputStream d = new DataInputStream(new FileInputStream("players.dat"));

        int count = d.readInt();

        for (int i = 0; i < count; i++) {
            Player pl = new Player(d.readInt());
            pl.name = d.readUTF();
            pl.exp = d.readInt();
            pl.tutorialState = d.readInt();
            pl.score = d.readInt();
            pl.gems = d.readInt();
            pl.gold = d.readInt();

            //Brawlers Array
            int c = d.readInt();
            pl.unlockedBrawlers = new int[c];

            for (int j = 0; j < c; j++){
                pl.unlockedBrawlers[j] = d.readInt();
            }

            pl.selectedBrawler = d.readInt();
            pl.roomID = d.readInt();
            pl.iconID = d.readInt();
            pl.nameColor = d.readInt();

            d.skip(16L);
            players.put(Integer.valueOf(pl.id), pl);
        }
        d.close();
    }

    public static void saveData() throws IOException {
        DataOutputStream d = new DataOutputStream(new FileOutputStream("players.dat"));

        d.writeInt(players.size());
        for (Player pl : players.values()) {
            d.writeInt(pl.id);
            d.writeUTF(pl.name);
            d.writeInt(pl.exp);
            d.writeInt(pl.tutorialState);

            d.writeInt(pl.score);
            d.writeInt(pl.gems);
            d.writeInt(pl.gold);

            //Brawlers Array
            d.writeInt(pl.unlockedBrawlers.length);
            for (int j = 0; j < pl.unlockedBrawlers.length; j++){
                d.writeInt(pl.unlockedBrawlers[j]);
            }

            d.writeInt(pl.selectedBrawler);
            d.writeInt(pl.roomID);
            d.writeInt(pl.iconID);
            d.writeInt(pl.nameColor);

            d.write(new byte[16]);
        }
        d.close();
    }


}
