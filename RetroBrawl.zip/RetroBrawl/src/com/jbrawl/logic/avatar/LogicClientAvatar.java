package com.jbrawl.logic.avatar;
import com.jbrawl.logic.Player;
import com.object.jnetwork.buffers.JByteBuffer;

import java.io.IOException;

public class LogicClientAvatar {
    public Player player;
    public LogicClientAvatar(Player player){
        this.player = player;
    }

    public void encode(JByteBuffer packet) throws IOException {
        packet.writeVInt(0);
        packet.writeVInt(player.id);

        packet.writeVInt(0);
        packet.writeVInt(0);

        packet.writeVInt(0);
        packet.writeVInt(0);

        packet.writeString(player.name);
        packet.writeBool(player.name != ""); //nameSet
        packet.writeString(null);

        packet.writeVInt(8); //commodity

        packet.writeVInt(player.unlockedBrawlers.length + 3);
        {
            for (int i = 0; i < player.unlockedBrawlers.length; i++) {
                packet.writeVInt(23);
                packet.writeVInt(player.unlockedBrawlers[i]);
                packet.writeVInt(1);
            }

            packet.writeVInt(5);
            packet.writeVInt(1);
            packet.writeVInt(10000);

            packet.writeVInt(5);
            packet.writeVInt(8);
            packet.writeVInt(10000);

            packet.writeVInt(5);
            packet.writeVInt(9);
            packet.writeVInt(10000);
        }
        packet.writeVInt(1);
        {
            packet.writeVInt(16);
            packet.writeVInt(0);
            packet.writeVInt(1);
        }
        packet.writeVInt(1);
        {
            packet.writeVInt(16);
            packet.writeVInt(0);
            packet.writeVInt(1);
        }

        packet.writeVInt(0);

        packet.writeVInt(1);
        {
            packet.writeVInt(16);
            packet.writeVInt(0);
            packet.writeVInt(1);
        }
        packet.writeVInt(1);
        {
            packet.writeVInt(16);
            packet.writeVInt(0);
            packet.writeVInt(10);
        }

        packet.writeVInt(0);
        packet.writeVInt(0);

        packet.writeVInt(9999);
        packet.writeVInt(0);
        packet.writeVInt(0);
        packet.writeVInt(0);
        packet.writeVInt(0);
        packet.writeVInt(0);
        packet.writeVInt(0);
        packet.writeVInt(0);
        packet.writeVInt(0);
        packet.writeVInt(0);
        packet.writeVInt(0);
        packet.writeVInt(2); //tutorialState
    }
}
