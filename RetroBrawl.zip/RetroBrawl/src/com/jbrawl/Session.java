package com.jbrawl;

import com.jbrawl.logic.Player;
import com.jbrawl.protocol.commands.server.BrawlBoxData;
import com.jbrawl.protocol.commands.server.ChangeNameResponse;
import com.jbrawl.protocol.messages.MessageInputStream;
import com.jbrawl.protocol.messages.MessageOutputStream;
import com.jbrawl.protocol.messages.PiranhaMessage;
import com.jbrawl.protocol.messages.client.alliance.AskForClubListMessage;
import com.jbrawl.protocol.messages.client.gamerooms.TeamCreateMessage;
import com.jbrawl.protocol.messages.client.gamerooms.TeamLeaveMessage;
import com.jbrawl.protocol.messages.client.home.ChangeAvatarNameMessage;
import com.jbrawl.protocol.messages.client.home.PlayerStatusMessage;
import com.jbrawl.protocol.messages.client.leaderboards.GetLeaderboardMessage;
import com.jbrawl.protocol.messages.client.logic.AnalyticsEventMessage;
import com.jbrawl.protocol.messages.client.logic.ClientCapabilitiesMessage;
import com.jbrawl.protocol.messages.client.logic.EndClientTurn;
import com.jbrawl.protocol.messages.client.login.KeepAliveMessage;
import com.jbrawl.protocol.messages.client.login.LoginMessage;
import com.jbrawl.protocol.messages.client.login.GetDeviceTokenMessage;
import com.jbrawl.protocol.messages.server.alliance.JoinableClubListMessage;
import com.jbrawl.protocol.messages.server.gamerooms.TeamLeftMessage;
import com.jbrawl.protocol.messages.server.gamerooms.TeamMessage;
import com.jbrawl.protocol.messages.server.home.OwnHomeDataMessage;
import com.jbrawl.protocol.messages.server.leaderboards.LeaderboardMessage;
import com.jbrawl.protocol.messages.server.login.KeepAliveServerMessage;
import com.jbrawl.protocol.messages.server.login.LoginOkMessage;

import java.io.IOException;

public class Session implements Runnable  {
    public Thread curr;
    public MessageInputStream input;
    public MessageOutputStream stream;
    public Player player;

    public void run() {
        try {
            work();
        } catch (Exception e) {
            if (!(e instanceof java.io.IOException) && !(e instanceof java.net.SocketException) && !(e instanceof java.io.EOFException))
                e.printStackTrace();
            try {
                input.close();
                player.current = null;
            } catch (Exception exception) { }
        }
    }

    public void work() throws Exception {
        LoginMessage login = (LoginMessage)this.input.read();
        System.out.println("Logging in " + login.vid);
        this.player = Player.load(login.vid);
        this.player.current = this;

        this.stream.write((PiranhaMessage) new LoginOkMessage(this.player.id));
        this.stream.write((PiranhaMessage)new OwnHomeDataMessage(this.player));
        while(!Thread.interrupted()) {
            PiranhaMessage packet = this.input.read();
            if(packet instanceof ClientCapabilitiesMessage){
                System.out.println("[ClientCapabilities] Latency: " + ((ClientCapabilitiesMessage) packet).latency);
                if(((ClientCapabilitiesMessage) packet).latency > 200){
                    System.out.println("[WARNING] High Latency! Latency " + ((ClientCapabilitiesMessage) packet).latency);
                }
            }
            else if(packet instanceof AskForClubListMessage){
                this.stream.write((PiranhaMessage) new JoinableClubListMessage());
            }
            else if(packet instanceof AnalyticsEventMessage){

            }
            else if(packet instanceof GetLeaderboardMessage){
                this.stream.write((PiranhaMessage) new LeaderboardMessage(player));
            }
            else if(packet instanceof ChangeAvatarNameMessage){
                this.stream.write((PiranhaMessage) new ChangeNameResponse(((ChangeAvatarNameMessage) packet).name));
                player.name = ((ChangeAvatarNameMessage) packet).name;
                Player.saveData();
            }
            else if(packet instanceof TeamLeaveMessage){
                this.stream.write((PiranhaMessage) new TeamLeftMessage());
            }
            else if(packet instanceof TeamCreateMessage){
                this.stream.write((PiranhaMessage) new TeamMessage());
            }
            else if(packet instanceof PlayerStatusMessage){

            }
            else if(packet instanceof GetDeviceTokenMessage){

            }
            else if(packet instanceof KeepAliveMessage){
                this.stream.write((PiranhaMessage)new KeepAliveServerMessage());
            }
            else if(packet instanceof EndClientTurn){
                switch(((EndClientTurn) packet).commandID){
                    case 500:
                        System.out.println("OpenBox");
                        this.stream.write((PiranhaMessage) new BrawlBoxData());
                        break;
                }
            }
        }
    }
}

