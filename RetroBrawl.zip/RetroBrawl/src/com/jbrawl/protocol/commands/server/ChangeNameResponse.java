package com.jbrawl.protocol.commands.server;

import com.jbrawl.protocol.messages.PiranhaMessage;
import com.object.jnetwork.buffers.JByteBuffer;

import java.io.IOException;

public class ChangeNameResponse extends PiranhaMessage {
    public String name;
    public ChangeNameResponse(String name){
        this.id = 24111;
        this.name = name;
    }

    @Override
    public void process() throws IOException{
        JByteBuffer packet = new JByteBuffer();

        packet.writeVInt(201);
        packet.writeString(name);
        packet.writeVInt(1);

        this.data = packet.toByteArray();
    }
}
