package com.jbrawl.protocol.commands.server;

import com.jbrawl.protocol.messages.PiranhaMessage;
import com.object.jnetwork.buffers.JByteBuffer;

import java.io.IOException;
import java.util.Random;

public class BrawlBoxData extends PiranhaMessage {

    public BrawlBoxData() {
        this.id = 24111;
    }
    @Override
    public void process() throws IOException {
        JByteBuffer packet = new JByteBuffer();
        Random rand;

        packet.writeVInt(203); //Command ID
        packet.writeVInt(0);
        packet.writeVInt(1);

        packet.writeVInt(11); //10 - mini box, 11 - mega box, 12 - big box

        packet.writeVInt(2); //rewards count

        //packet.writeVInt(16);
        //packet.writeVInt(23);
        //packet.writeVInt(1);

        packet.writeVInt(1000); //gold dropped

        packet.writeVInt(0);
        packet.writeVInt(7);

        packet.writeVInt(0);
        packet.writeVInt(0);
        packet.writeVInt(0);

        packet.writeVInt(1);
        packet.writeVInt(16);
        packet.writeVInt(23); //brawler id
        packet.writeVInt(1);

        packet.writeVInt(0);
        packet.writeVInt(0);
        packet.writeVInt(0);

        /*packet.writeVInt(20);
        packet.writeVInt(23);
        packet.writeVInt(0);
        packet.writeVInt(6);

        packet.writeVInt(0);
        packet.writeVInt(0);
        packet.writeVInt(0);*/

        for (int i = 0; i < 13; i++){

            packet.writeVInt(0);
        }

        /*packet.writeVInt(2);
        packet.writeVInt(888); //gold

        packet.writeVInt(0);
        packet.writeVInt(7);
        packet.writeVInt(0);
        packet.writeVInt(0);
        packet.writeVInt(0);
        packet.writeVInt(1);

        packet.writeVInt(15); //bonus value
        packet.writeVInt(0);

        packet.writeVInt(8); //8 - gems, 3 - tickets*/

        packet.writeVInt(0);
        packet.writeVInt(0);
        packet.writeVInt(0);
        packet.writeVInt(1);
        packet.writeVInt(-1);
        packet.writeVInt(-1);
        packet.writeVInt(0);
        packet.writeVInt(0);
        this.data = packet.toByteArray();
    }
}
