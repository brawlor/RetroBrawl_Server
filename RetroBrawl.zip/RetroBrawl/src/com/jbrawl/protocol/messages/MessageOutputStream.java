package com.jbrawl.protocol.messages;

import com.object.jnetwork.ClientSocket;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;

public class MessageOutputStream {
    public ClientSocket socket;

    public MessageOutputStream(ClientSocket client){
        this.socket = client;
    }

    public void write(PiranhaMessage p) throws Exception {
        ByteArrayOutputStream b = new ByteArrayOutputStream();
        DataOutputStream d = new DataOutputStream(b);
        byte[] cb = {(byte)0xFF, (byte)0xFF, 0, 0, 0, 0, 0};
        p.process();
        d.writeChar(p.id);
        d.write(p.data.length >>> 16);
        d.write(p.data.length >>> 8);
        d.write(p.data.length >>> 0);
        d.writeChar(p.version);
        d.write(p.data);
        d.write(cb);
        byte[] out = b.toByteArray();
        socket.sendPacket(out);
        System.out.println("Message " + p.id + " has been sent.");
    }
}
