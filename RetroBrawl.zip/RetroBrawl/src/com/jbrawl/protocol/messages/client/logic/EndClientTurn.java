package com.jbrawl.protocol.messages.client.logic;

import com.jbrawl.logic.Player;
import com.jbrawl.protocol.messages.PiranhaMessage;
import com.object.jnetwork.buffers.JByteReader;

import java.io.IOException;

public class EndClientTurn extends PiranhaMessage {

    public int commandID;
    public Player player;
    public EndClientTurn(){
    }

    @Override
    public void process() throws IOException {
        JByteReader packet = new JByteReader(this.data);

        packet.readVInt();
        packet.readVInt();
        packet.readVInt();
        packet.readVInt();

        this.commandID = packet.readVInt();

        switch (commandID){
            case 500:
                System.out.println("Open Box");
                break;
            default:
                //TODO: OutOfSync
                break;
        }
    }
}
