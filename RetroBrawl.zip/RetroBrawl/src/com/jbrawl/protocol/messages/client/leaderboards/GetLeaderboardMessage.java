package com.jbrawl.protocol.messages.client.leaderboards;

import com.jbrawl.protocol.messages.PiranhaMessage;

import java.io.IOException;

public class GetLeaderboardMessage extends PiranhaMessage {

    @Override
    public void process() throws IOException{

    }
}
