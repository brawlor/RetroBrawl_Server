package com.jbrawl.protocol.messages.client.logic;

import com.jbrawl.protocol.messages.PiranhaMessage;
import com.object.jnetwork.buffers.JByteReader;

import java.io.IOException;

public class ClientCapabilitiesMessage extends PiranhaMessage {
    public int latency;

    @Override
    public void process() throws IOException{
        JByteReader packet = new JByteReader(this.data);
        this.latency = packet.readVInt();
    }
}
