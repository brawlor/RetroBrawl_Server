package com.jbrawl.protocol.messages.client.login;

import com.jbrawl.protocol.messages.PiranhaMessage;
import com.object.jnetwork.buffers.JByteReader;

import java.io.IOException;

public class LoginMessage extends PiranhaMessage {

    JByteReader packet;
    public int vid;

    @Override
    public void process() throws IOException {
        packet = new JByteReader(this.data);

        packet.readInt32();
        this.vid = packet.readInt32();
    }
}
