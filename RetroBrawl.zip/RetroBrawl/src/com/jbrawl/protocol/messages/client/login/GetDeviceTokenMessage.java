package com.jbrawl.protocol.messages.client.login;

import com.jbrawl.protocol.messages.PiranhaMessage;

public class GetDeviceTokenMessage extends PiranhaMessage {
    @Override
    public void process(){

    }
}
