package com.jbrawl.protocol.messages.client.home;

import com.jbrawl.protocol.messages.PiranhaMessage;

import java.io.IOException;

public class PlayerStatusMessage extends PiranhaMessage {
    @Override
    public void process() throws IOException {

    }
}
