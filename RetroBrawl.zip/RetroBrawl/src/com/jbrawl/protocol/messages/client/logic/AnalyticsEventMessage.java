package com.jbrawl.protocol.messages.client.logic;

import com.jbrawl.protocol.messages.PiranhaMessage;
import com.object.jnetwork.buffers.JByteReader;

import java.io.IOException;

public class AnalyticsEventMessage extends PiranhaMessage {
     @Override
    public void process() throws IOException{
         JByteReader packet = new JByteReader(this.data);

         String v1 = packet.readString();
         String v2 = packet.readString();

         System.out.println("[DEBUG] " + v1 + " " + v2);
     }
}
