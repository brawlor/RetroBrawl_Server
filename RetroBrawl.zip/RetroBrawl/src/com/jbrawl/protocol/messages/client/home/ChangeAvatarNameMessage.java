package com.jbrawl.protocol.messages.client.home;

import com.jbrawl.protocol.messages.PiranhaMessage;
import com.object.jnetwork.buffers.JByteReader;

import java.io.IOException;

public class ChangeAvatarNameMessage extends PiranhaMessage {
    public String name;

    @Override
    public void process() throws IOException{
        JByteReader packet = new JByteReader(this.data);

        name = packet.readString();
    }
}
