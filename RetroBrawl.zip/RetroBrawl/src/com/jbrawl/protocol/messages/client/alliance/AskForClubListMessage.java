package com.jbrawl.protocol.messages.client.alliance;

import com.jbrawl.protocol.messages.PiranhaMessage;

import java.io.IOException;

public class AskForClubListMessage extends PiranhaMessage {
    @Override
    public void process() throws IOException {

    }
}
