package com.jbrawl.protocol.messages.client.gamerooms;

import com.jbrawl.protocol.messages.PiranhaMessage;

import java.io.IOException;

public class TeamCreateMessage extends PiranhaMessage {

    @Override
    public void process() throws IOException {

    }
}
