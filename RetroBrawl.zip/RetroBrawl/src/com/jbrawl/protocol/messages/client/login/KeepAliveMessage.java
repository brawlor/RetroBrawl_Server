package com.jbrawl.protocol.messages.client.login;

import com.jbrawl.protocol.messages.PiranhaMessage;

import java.io.IOException;

public class KeepAliveMessage extends PiranhaMessage {

    @Override
    public void process() throws IOException{

    }

}
