package com.jbrawl.protocol.messages;

import java.io.IOException;

public abstract class PiranhaMessage {
    public int id;
    public byte[] data = new byte[0];
    public int version;

    public abstract void process() throws IOException, Exception;
}