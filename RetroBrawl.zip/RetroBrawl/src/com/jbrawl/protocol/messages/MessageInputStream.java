package com.jbrawl.protocol.messages;

import com.jbrawl.protocol.messages.client.alliance.AskForClubListMessage;
import com.jbrawl.protocol.messages.client.gamerooms.TeamCreateMessage;
import com.jbrawl.protocol.messages.client.gamerooms.TeamLeaveMessage;
import com.jbrawl.protocol.messages.client.home.ChangeAvatarNameMessage;
import com.jbrawl.protocol.messages.client.home.PlayerStatusMessage;
import com.jbrawl.protocol.messages.client.leaderboards.GetLeaderboardMessage;
import com.jbrawl.protocol.messages.client.logic.AnalyticsEventMessage;
import com.jbrawl.protocol.messages.client.logic.ClientCapabilitiesMessage;
import com.jbrawl.protocol.messages.client.logic.EndClientTurn;
import com.jbrawl.protocol.messages.client.login.KeepAliveMessage;
import com.jbrawl.protocol.messages.client.login.LoginMessage;
import com.jbrawl.protocol.messages.client.login.GetDeviceTokenMessage;
import com.jbrawl.protocol.messages.server.gamerooms.TeamLeftMessage;
import com.object.jnetwork.ClientSocket;

import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.IOException;

public class MessageInputStream {
    public ClientSocket socket;
    public boolean connected = true;

    public MessageInputStream(ClientSocket socket){
        this.socket = socket;
    }

    public PiranhaMessage read() throws Exception {
        if (connected) {
            byte[] buff = socket.readPacket();

            ByteArrayInputStream b = new ByteArrayInputStream(buff);
            DataInputStream d = new DataInputStream(b);

            int type = d.readChar();
            int length = d.read() << 16 | d.read() << 8 | d.read();
            char version = d.readChar();

            byte[] data = new byte[length];
            d.read(data);
            PiranhaMessage p = null;
            if(type > 0) {
                switch (type){
                    case 10100: //ClientHello
                        System.out.println("NaCl detected!");
                        //LoginFailed
                        break;
                    case 10101: //LoginMessage
                        System.out.println("Login");
                        p = new LoginMessage();
                        p.id = type;
                        p.version = version;
                        p.data = data;
                        p.process();
                        return p;
                    case 10110:
                        p = new AnalyticsEventMessage();
                        p.id = type;
                        p.version = version;
                        p.data = data;
                        p.process();
                        return p;
                    case 10107:
                        p = new ClientCapabilitiesMessage();
                        p.id = type;
                        p.version = version;
                        p.data = data;
                        p.process();
                        return p;
                    case 10108:
                        p = new KeepAliveMessage();
                        p.id = type;
                        p.version = version;
                        p.data = data;
                        p.process();
                        return p;
                    case 10212:
                        p = new ChangeAvatarNameMessage();
                        p.id = type;
                        p.version = version;
                        p.data = data;
                        p.process();
                        return p;
                    case 14102:
                        System.out.println("EndClientTurn");
                        p = new EndClientTurn();
                        p.id = type;
                        p.version = version;
                        p.data = data;
                        p.process();
                        return p;
                    case 14303:
                        p = new AskForClubListMessage();
                        p.id = type;
                        p.version = version;
                        p.data = data;
                        p.process();
                        return p;
                    case 14350:
                        p = new TeamCreateMessage();
                        p.id = type;
                        p.version = version;
                        p.data = data;
                        p.process();
                        return p;
                    case 14353:
                        p = new TeamLeaveMessage();
                        p.id = type;
                        p.version = version;
                        p.data = data;
                        p.process();
                        return p;
                    case 14403:
                        p = new GetLeaderboardMessage();
                        p.id = type;
                        p.version = version;
                        p.data = data;
                        p.process();
                        return p;
                    default:
                        System.out.println("Unhandled: " + type);
                        break;
                }
                return null;
            }
            else {
                close();
                System.out.println("Client Disconnected");
            }
        }
        return null; //return null
    }

    public void close() throws IOException {
        socket.close();
        connected = false;
    }
}
