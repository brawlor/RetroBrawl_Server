package com.jbrawl.protocol.messages.server.leaderboards;

import com.jbrawl.logic.Player;
import com.jbrawl.protocol.messages.PiranhaMessage;
import com.object.jnetwork.buffers.JByteBuffer;

import java.io.IOException;
import java.util.Map;

public class LeaderboardMessage extends PiranhaMessage {
    public Player player;
    public LeaderboardMessage(Player player){
        this.id = 24403;
        this.player = player;
    }

    @Override
    public void process() throws IOException {
        JByteBuffer packet = new JByteBuffer();

        packet.writeVInt(1);
        //packet.writeVInt(0);
        packet.writeVInt(0);
        packet.writeString(null); //region

        packet.writeVInt(1);
        System.out.println(Player.players.size());

        //for (Map.Entry<Integer, Player> entry : Player.players.entrySet()){
           //Player pl = entry.getValue();
           // System.out.println("GG" + entry.getKey());

            //if(entry.getKey() != 1383209642) {
                packet.writeVInt(0);
                packet.writeVInt(player.id);

                packet.writeVInt(1);
                packet.writeVInt(player.score);

                packet.writeVInt(1);

                packet.writeString(null);
                packet.writeString(player.name);

                packet.writeVInt(100); //level?
                packet.writeVInt(28000000 + player.iconID);
                packet.writeVInt(43000000 + player.nameColor);
                packet.writeVInt(0);
            //}
        //}

        packet.writeVInt(0);
        packet.writeVInt(0);
        packet.writeVInt(0);
        packet.writeVInt(0);
        packet.writeString("CA");

        this.data = packet.toByteArray();
    }
}
