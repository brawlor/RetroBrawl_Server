package com.jbrawl.protocol.messages.server.login;

import com.jbrawl.protocol.messages.PiranhaMessage;
import com.object.jnetwork.buffers.JByteBuffer;

import java.io.IOException;

public class OutOfSyncMessage extends PiranhaMessage {

    public OutOfSyncMessage() {
        this.id = 24104;
    }

    @Override
    public void process() throws IOException{
        JByteBuffer packet = new JByteBuffer();

        packet.writeInt32(0);

        this.data = packet.toByteArray();
    }
}
