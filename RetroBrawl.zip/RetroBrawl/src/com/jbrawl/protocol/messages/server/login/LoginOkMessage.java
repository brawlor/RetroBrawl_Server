package com.jbrawl.protocol.messages.server.login;

import com.jbrawl.protocol.messages.PiranhaMessage;
import com.object.jnetwork.buffers.JByteBuffer;

import java.io.IOException;

public class LoginOkMessage extends PiranhaMessage {

    JByteBuffer packet;
    public int lowID;

    public LoginOkMessage(int lowID) {
        this.id = 20104;
        this.lowID = lowID;
    }

    @Override
    public void process() throws IOException {

        packet = new JByteBuffer();

        //true structure

        packet.writeInt64(lowID);
        packet.writeInt64(lowID);

        packet.writeString("Token");
        packet.writeString(null);
        packet.writeString(null);

        packet.writeInt32(19);
        packet.writeInt32(102);
        packet.writeInt32(0);

        packet.writeString("integration");

        packet.writeInt32(1);
        packet.writeInt32(1);
        packet.writeInt32(62);

        packet.writeString(null);

        //ByteStream::isAtEnd()

        packet.writeString(null);
        packet.writeString(null);

        //ByteStream::isAtEnd()

        this.data = packet.toByteArray();
    }
}
