package com.jbrawl.protocol.messages.server.login;


import com.jbrawl.protocol.messages.PiranhaMessage;

public class KeepAliveServerMessage extends PiranhaMessage {

    public KeepAliveServerMessage(){
        this.id = 20108;
    }

    @Override
    public void process(){

    }
}
