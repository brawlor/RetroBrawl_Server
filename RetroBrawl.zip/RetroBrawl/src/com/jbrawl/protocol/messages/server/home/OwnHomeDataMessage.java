package com.jbrawl.protocol.messages.server.home;

import com.jbrawl.logic.Player;
import com.jbrawl.logic.avatar.LogicClientAvatar;
import com.jbrawl.logic.home.LogicClientHome;
import com.jbrawl.protocol.messages.PiranhaMessage;
import com.object.jnetwork.buffers.JByteBuffer;

import java.io.IOException;

public class OwnHomeDataMessage extends PiranhaMessage {

    JByteBuffer packet;
    Player player;

    public OwnHomeDataMessage(Player player) {
        this.id = 24101;
        this.player = player;
    }

    @Override
    public void process() throws IOException {
        packet = new JByteBuffer();

        LogicClientHome home = new LogicClientHome(player);
        home.encode(packet);

        LogicClientAvatar avatar = new LogicClientAvatar(player);
        avatar.encode(packet);

        packet.writeVInt(1585502369);
        System.out.println("OwnHomeData ID: " + player.id);

        Player.saveData();

        this.data = packet.toByteArray();
    }
}
