package com.jbrawl.protocol.messages.server.gamerooms;

import com.jbrawl.protocol.messages.PiranhaMessage;
import com.object.jnetwork.buffers.JByteBuffer;

import java.io.IOException;

public class TeamLeftMessage extends PiranhaMessage {

    public TeamLeftMessage(){
        this.id = 24125;
    }

    @Override
    public void process() throws IOException {
        JByteBuffer packet = new JByteBuffer();

        packet.writeInt32(0);

        this.data = packet.toByteArray();
    }
}
