package com.jbrawl.protocol.messages.server.gamerooms;

import com.jbrawl.protocol.messages.PiranhaMessage;
import com.object.jnetwork.buffers.JByteBuffer;

import java.io.IOException;

public class TeamMessage extends PiranhaMessage {

    public TeamMessage(){
        this.id = 24124;
    }

    @Override
    public void process() throws IOException{
        JByteBuffer packet = new JByteBuffer();

        packet.writeVInt(1);
        packet.writeVInt(0);
        packet.writeVInt(1);

        packet.writeInt32(0);
        packet.writeInt32(1);

        packet.writeVInt(1); //timestamp

        packet.writeVInt(0);
        packet.writeVInt(0);
        packet.writeVInt(0);

        packet.writeVInt(15);
        packet.writeVInt(7);

        packet.writeVInt(1);
        {
            //packet.writeHexa("01000000000000000110000000010300000000");
            packet.writeVInt(1);
            packet.writeVInt(0);
            packet.writeVInt(0);
            packet.writeVInt(0);
            packet.writeVInt(0);
            packet.writeVInt(0);
            packet.writeVInt(0);
            packet.writeVInt(0);
            packet.writeVInt(1);

            packet.writeVInt(16);
            packet.writeVInt(0); //selected brawler

            packet.writeVInt(0);
            packet.writeVInt(0);
            packet.writeVInt(1);
            packet.writeVInt(3);
            packet.writeVInt(0);
            packet.writeVInt(0);
            packet.writeVInt(0);
            packet.writeVInt(0);

            packet.writeString("XeonDEV");
            packet.writeHexa("A40180FCD91A80838129178C01");
        }
        packet.writeInt32(6);

        //packet.writeHexa("0100010000000077d29289b9a5ffcc0b0000000f070101000000000000000110000000010300000000000000054775657374a40180fcd91a80838129178c0100000006");

        this.data = packet.toByteArray();
    }
}
