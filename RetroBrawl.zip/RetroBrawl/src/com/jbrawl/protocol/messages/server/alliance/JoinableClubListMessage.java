package com.jbrawl.protocol.messages.server.alliance;

import com.jbrawl.protocol.messages.PiranhaMessage;
import com.object.jnetwork.buffers.JByteBuffer;

import java.io.IOException;

public class JoinableClubListMessage extends PiranhaMessage {

    public JoinableClubListMessage() {
        this.id = 24304;
    }

    @Override
    public void process() throws Exception {
        JByteBuffer packet = new JByteBuffer();

        packet.writeVInt(1); //count

        packet.writeInt64(1); //club id
        packet.writeString("DudnikLand");

        packet.writeVInt(8);
        packet.writeVInt(0);

        packet.writeVInt(0); //CLUB TYPE

        packet.writeVInt(1); //members
        packet.writeVInt(0);

        packet.writeVInt(0);

        packet.writeString("CA");

        packet.writeVInt(1);
        packet.writeVInt(0);

        this.data = packet.toByteArray();
    }
}
