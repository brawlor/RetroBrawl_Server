package com.jbrawl;

import com.jbrawl.logic.Player;
import com.jbrawl.protocol.messages.MessageInputStream;
import com.jbrawl.protocol.messages.MessageOutputStream;
import com.object.jnetwork.ClientSocket;
import com.object.jnetwork.Server;

import java.io.IOException;

public class Main {

    public static Server server;
    public static void main(String[] args) throws IOException {
        System.out.println("Preparing Server...");
        Player.loadSavedData();
        server = new Server(9339); //Starting Server at port 9339
        System.out.println("Server started on port 9339");

        while(true) {
            ClientSocket socket = server.acceptClient();
            Session thread;
            try {
                thread = new Session();
                thread.curr = new Thread(thread);
                System.out.println("New connection!");
                thread.input = new MessageInputStream(socket);
                thread.stream = new MessageOutputStream(socket);
                thread.curr.start();
            } catch (Exception e) {}
        }
    }
}
